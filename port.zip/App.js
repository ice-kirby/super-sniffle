import "./App.css";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import Home from "./components/Home";
import NotFound from "./components/NotFound";
import Root from "./components/Root";
import Product from "./components/Product";
import Game from "./components/Game";
import Project from "./components/Project";

const router = createBrowserRouter([
  {
    path: "/",
    element: <Root />,
    errorElement: <NotFound />,
    children: [
      { index: true, element: <Home /> },
      { path: "/product", element: <Product /> },
      { path: "/project", element: <Project /> },
      { path: "/velog", element: <Game /> },
    ],
  },
]);

function App() {
  return <RouterProvider router={router} />;
}

export default App;
