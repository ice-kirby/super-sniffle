import React from "react";

const Project = () => {
  return <div>토이프로젝트</div>;
};

export default Project;
