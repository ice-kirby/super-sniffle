import React from "react";

const Game = () => {
  return <div>내 벨로그</div>;
};

export default Game;
