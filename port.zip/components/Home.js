import React from "react";
import "../style/Home.scss";
import Photo from "./Photo";

const Home = () => {
  return (
    <div className="HomeAll">
      <div className="first">
        <div className="wrap">
          <Photo />
        </div>
        <div className="wordOne">개발자로 향하는 성장물의 주인공</div>

        <div className="wordTwo">최나은 등장</div>
      </div>
      <div>
        <div>소통과 협업 능력, 기획력</div>
        <div>계획과 행동의 중요성</div>
        <div>
          소비자 친화적인 기능을 구현하고 싶습니다. 개선이 필요한 부분을 막연히
          기다리기보다 직접 해결책을 제시할 수 있는 개발자가 되겠습니다.
        </div>
        상상력이 담긴 코드로 다가가겠습니다.
      </div>
    </div>
  );
};

export default Home;
