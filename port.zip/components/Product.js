import React from "react";

const Product = () => {
  return <div>얘는 프로덕트</div>;
};

export default Product;
