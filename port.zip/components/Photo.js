import React from "react";
import "../style/Photo.scss";

const Photo = () => {
  return (
    <div className="wrap">
      <img src="medias/kirby.png" className="target" />
    </div>
  );
};

export default Photo;
