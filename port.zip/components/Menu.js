import React from "react";
import { Link } from "react-router-dom";
import "../style/Menu.scss";

const Menu = () => {
  return (
    <div>
      <ul>
        <li>
          <Link to="/">최나은</Link>
        </li>
        <li>
          <Link to="/product">연혁 🎁</Link>
        </li>
        <li>
          <Link to="/project">나의 대작들 🏛</Link>
        </li>
        <li>
          <Link to="/velog">velog 📗</Link>
        </li>
      </ul>
    </div>
  );
};

export default Menu;
