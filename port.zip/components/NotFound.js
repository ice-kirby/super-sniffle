import React from "react";

const NotFound = () => {
  return <div>에러났어용</div>;
};

export default NotFound;
