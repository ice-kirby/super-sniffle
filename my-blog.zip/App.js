import { useEffect, useMemo, useReducer, useRef } from "react";
import "./App.css";
import DiaryEditor from "./components/DiaryEditor";
import DiaryList from "./components/DiaryList";

const reducer = (state, action) => {
  switch (action.type) {
    case "CREATE": {
      const created_date = new Date().getTime();
      const newItem = { ...action.data, created_date };
      return [newItem, ...state];
    }
    case "REMOVE": {
      return state.filter((jo) => jo.id !== action.targetId);
    }
    case "EDIT": {
      return state.map((jo) =>
        jo.id === action.targetId ? { ...jo, content: action.newContent } : jo
      );
    }
    default:
      return state;
  }
};

function App() {
  const [data, dispatch] = useReducer(reducer, []);

  const dataId = useRef(0);

  const onCreate = (user, content, emotion) => {
    dispatch({
      type: "CREATE",
      data: { user, content, emotion, id: dataId.current },
    });

    dataId.current += 1;
  };

  function onRemove(targetId) {
    dispatch({ type: "REMOVE", targetId });
  }

  function onEdit(targetId, newContent) {
    dispatch({ type: "EDIT", targetId, newContent });
  }

  // const Kibun = useMemo(() => {
  //   const goodCount = data.filter((jo) => jo.emotion >= 3).length;
  //   const badCount = data.length - goodCount;
  //   const goodRatio = (goodCount / data.length) * 100;
  //   return { goodCount, badCount, goodRatio };
  // }, [data.length]);

  // const { goodCount, badCount, goodRatio } = Kibun;

  return (
    <div className="App">
      <DiaryEditor onCreate={onCreate} />

      {/* <div>전체 일기 : {data.length}</div>
      <div>기분 좋은 일기 : {goodCount}</div>
      <div>기분 나쁜 일기 : {badCount}</div>
      <div>기분 좋은 일기 비율 : {goodRatio}</div> */}

      <DiaryList onEdit={onEdit} onRemove={onRemove} diarylist={data} />
    </div>
  );
}

export default App;
