import React, { useEffect, useRef, useState } from "react";

const Unmount = () => {
  useEffect(() => {
    console.log("mount!");
    return () => {
      console.log("unmount!");
    };
  }, []);
  return <div>unmount testing</div>;
};

const Lifecycle = () => {
  const [isVI, setIsVi] = useState(false);
  const toggle = () => setIsVi(!isVI);

  return (
    <div style={{ padding: 30 }}>
      <button onClick={toggle}>on/off</button>
      {isVI && <Unmount />}
    </div>
  );
};

export default Lifecycle;
