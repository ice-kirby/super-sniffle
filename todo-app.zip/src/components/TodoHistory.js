import React, { useState, useEffect } from "react";
import "../style/TodoHistory.scss";
import TodoHistoryC from "./TodoHistoryC";

const TodoHistory = (props) => {
  const { jinan, jiwarItem } = props;
  const [filter, setFilter] = useState([...jinan]);
  const [wall, setWall] = useState("");

  function clickWall(e) {
    setWall(e.target.value);
  }

  useEffect(() => {
    setFilter(jinan.filter((it) => it.date.slice(0, 7) === wall));
  }, [wall, jinan]);

  return (
    <div className="TodoHistory">
      <input type="month" onChange={clickWall} />
      {filter.map((jo) => (
        <TodoHistoryC jina={jo} key={jo.id} jiwarItem={jiwarItem} />
      ))}
    </div>
  );
};

export default TodoHistory;
