import React, {
  useCallback,
  useEffect,
  useMemo,
  useReducer,
  useRef,
} from "react";
import "./App.css";
import DiaryEditor from "./components/DiaryEditor";
import DiaryList from "./components/DiaryList";

const reducer = (state, action) => {
  let newState = [];
  switch (action.type) {
    case "INIT": {
      newState = action.data;
    }
    case "CREATE": {
      const created_date = new Date().getTime();
      const newItem = { ...action.data, created_date };
      newState = [newItem, ...state];
      break;
    }
    case "REMOVE": {
      newState = state.filter((jo) => jo.id !== action.targetId);
      break;
    }
    case "EDIT": {
      newState = state.map((jo) =>
        jo.id === action.targetId ? { ...jo, content: action.newContent } : jo
      );
      break;
    }
    default:
      return state;
  }
  localStorage.setItem("diary", JSON.stringify(newState), [newState]);
  return newState;
};

function App() {
  const [data, dispatch] = useReducer(reducer, []);

  useEffect(() => {
    const localData = localStorage.getItem("diary");
    if (localData) {
      const diaryList = JSON.parse(localData).sort(
        (a, b) => parseInt(b.id) - parseInt(a.id)
      );
      dataId.current = parseInt(diaryList[0].id) + 1;

      console.log(diaryList);
      console.log(dataId);

      dispatch({ type: "INIT", data: diaryList });
    }
  }, []);

  const dataId = useRef(0);

  const onCreate = useCallback((user, content, emotion) => {
    dispatch({
      type: "CREATE",
      data: { user, content, emotion, id: dataId.current },
    });
    dataId.current += 1;
  }, []);

  const onRemove = useCallback((targetId) => {
    dispatch({ type: "REMOVE", targetId });
  }, []);

  const onEdit = useCallback((targetId, newContent) => {
    dispatch({ type: "EDIT", targetId, newContent });
  }, []);

  // const Kibun = useMemo(() => {
  //   const goodCount = data.filter((jo) => jo.emotion >= 3).length;
  //   const badCount = data.length - goodCount;
  //   const goodRatio = (goodCount / data.length) * 100;
  //   return { goodCount, badCount, goodRatio };
  // }, [data.length]);

  // const { goodCount, badCount, goodRatio } = Kibun;

  return (
    <div className="App">
      <DiaryEditor onCreate={onCreate} />

      {/* <div>전체 일기 : {data.length}</div>
      <div>기분 좋은 일기 : {goodCount}</div>
      <div>기분 나쁜 일기 : {badCount}</div>
    <div>기분 좋은 일기 비율 : {goodRatio}</div> */}

      <DiaryList onEdit={onEdit} onRemove={onRemove} diarylist={data} />
    </div>
  );
}

export default App;
